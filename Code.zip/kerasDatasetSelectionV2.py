import numpy as np
import random
from numpy import genfromtxt
from keras.models import Sequential
from keras.layers.core import Dense, Activation
from sklearn import metrics
from sklearn.model_selection import train_test_split
from keras.utils import Sequence

from playsound import playsound

def main():

    # My sequence class declaration
    class CIFAR10Sequence(Sequence):

        # Here, `x_set` is list of path to the images
        # and `y_set` are the associated classes.
        # ~ My best guess is that I set x_set as a n-dimensional array with 1000 rows, each containing the information
        # ~ of one of the 1000 randomly undersampled datasets. I then set y_set as the n-dimensional array of lists of
        # ~ the proper class for the data values.
        # ~
        # ~ The value of batch size is a bit of a mystery to me. From what I can tell, it has to be between 1 and the size
        # ~ of the dataset being used as training data, and it will divide the total number of data values by the batch_size
        # ~ variable to determine how many batches there are in each epoch. I'm not sure what value to pick, however.
        # ~ It is currently set at 68, so there are 2 batches for every epoch, not sure if a lower number is better.
        def __init__(self, x_set, y_set, batch_size):
            self.x, self.y = x_set, y_set
            self.epoch = 0
            self.batch_size = batch_size

        def __len__(self):
            return int(np.ceil(len(self.x) / float(self.batch_size)))

        def __getitem__(self, idx):
            batch_x = self.x[idx * self.batch_size:(idx + 1) * self.batch_size]
            batch_y = self.y[idx * self.batch_size:(idx + 1) * self.batch_size]

            # Not sure what to return here. The commented code below is what came with this general layout, geared
            # towards images.

            # return np.array([
            #     resize(imread(file_name), (200, 200))
            #        for file_name in batch_x]), np.array(batch_y)

        # ~ This is the method called at the end of each epoch
        def on_epoch_end(self):
            # Activates after every epoch
            if self.epoch % 1 == 0:
                pass
            self.epoch += 1

    ###########################

    ############################################ Read In Data From File ################################################
    # Read in column 0 from Table1 for the name of the galaxy
    galaxyName = genfromtxt('Paper2Table1.csv', delimiter=',', skip_header=1, dtype=None, encoding="utf8", usecols=0)

    # Read in Column 6 from Table1 (Maser Classification)
    maserType = genfromtxt('Paper2Table1.csv', delimiter=',', skip_header=1, dtype=None, encoding="utf8", usecols=6)

    # Read in L12 from Table1
    L12 = genfromtxt('Paper2Table1.csv', delimiter=',', skip_header=1, dtype=None, encoding="utf8", usecols=7)

    # Read in Lobs from Table2
    Lobs = genfromtxt('Paper2Table2.csv', delimiter=',', skip_header=1, dtype=None, encoding="utf8", usecols=4)

    ########################################## Normalize the Data ######################################################
    # Normalize L12
    maxValL12 = np.amax(L12)
    minValL12 = np.amin(L12)
    countL12 = 0
    for value in L12:
        L12[countL12] = (value - minValL12) / (maxValL12 - minValL12)
        countL12 += 1

    # Normalize Lobs
    maxValLobs = np.amax(Lobs)
    minValLobs = np.amin(Lobs)
    countLobs = 0
    for value in Lobs:
        Lobs[countLobs] = (value - minValLobs) / (maxValLobs - minValLobs)
        countLobs += 1

    ########################################## Reshape the Data Matrix #################################################
    # Currently, the shape of the data matrix is flipped
    # Reshape the data matrix to have 2 columns, one for each attribute
    # and as many rows as there are examples (galaxies)
    data = []
    count = 0
    for value in L12:
        data.append([L12[count], Lobs[count]])
        count += 1

    if len(data) == 642 and len(data[0]) == 2 and len(maserType) == 642:
        print("Data loaded properly")
    else:
        exit("Data loaded improperly")

    print("Length of data = ", len(data))
    print("Length of Data[0]", len(data[0]))
    print("Length of MaserType[] = ", len(maserType))

    ########################################## Sort the Masers from the Non-Masers #####################################
    # Sort out the masers and non masers for selection of training data
    # Change all non-zero values of maser classification to 1 for easy binary classification
    # Create a list of all non-masers and masers
    masers = []
    nonMasers = []

    count = 0
    # This is the number of masers; will be used to know how many non-masers to choose for the training data
    maserCount = 0
    for value in maserType:
        if value > 0:
            maserType[count] = 1
            maserCount += 1
            masers.append(data[count])
            count += 1
        else:
            nonMasers.append(data[count])
            count += 1

    if len(masers) == 68 and len(nonMasers) == 574:
        print("Total Masers and NonMasers Separated Correctly")
        print("Number of Total Maser Galaxies = ", len(masers))
        print("Number of Total NonMaser Galaxies = ", len(nonMasers))
    else:
        exit("Maser and NonMaser Separation Error")


    ######################################Build the Model and Call the Sequence Method #################################

    # the "result" array from undersampling method
    # Shape of arrayOfDatasets = (1000, 6) -> Array of the 1000 subsampled datasets
    # Shape of arrayOfDatasets[0] = (6, varying) -> array of the split-up datasets (train, validation, test)
    # Shape of arrayOfDatasets[0][0] = (81, 2) -> array of xTrain, the training data for this subsampled dataset
    # Shape of arrayOfDatasets[0][1] = (81,) -> Array of yTrain, the classification for the training data
    # Shape of arrayOfDatasets[0][2] = (27, 2) -> Array of xValid, the validation data for this subsampled dataset
    # Shape of arrayOfDatasets[0][3] = (27,) -> Array of yValid, the classification for the validation data
    # Shape of arrayOfDataset[0][4] = (28, 2) -> Array of xTest, the test data for this subsampled dataset
    # Shape of arrayOfDataset[0][5] = (28,) -> Array of yTest, the classification for the test test data
    arrayOfDatasets = undersampling(nonMasers, masers, maserCount)
    print("Shape of arrayOfDatasets[0][5] = ", arrayOfDatasets[0][5].shape)
    print("Length of arrayOfDatasets = ", len(arrayOfDatasets))
    print("Type of arrayOfDatasets[0][0] = ", type(arrayOfDatasets[0][0]))
    print("arrayOfDatasets[0][0][0] = ", arrayOfDatasets[0][0][0])
    print("arrayOfDatasets[0][1][0] = ", arrayOfDatasets[0][1][0])

    xTrain = []
    yTrain = []
    xValid = []
    yValid = []
    xTest = []
    yTest = []

    count = 0
    for value in arrayOfDatasets:
        xTrain.append(arrayOfDatasets[count][0])
        yTrain.append(arrayOfDatasets[count][1])
        xValid.append(arrayOfDatasets[count][2])
        yValid.append(arrayOfDatasets[count][3])
        xTest.append(arrayOfDatasets[count][4])
        yTest.append(arrayOfDatasets[count][5])
        count += 1

    batchSize = 68
    num_epochs = 1000

    # This sequence receives all xTrain and yTrain values for every subset.
    sequence = CIFAR10Sequence(np.array(xTrain), np.array(yTrain), batchSize)

    model = Sequential()
    model.add(Dense(5, input_dim=2, activation='relu'))
    model.add(Dense(4, activation='relu'))
    model.add(Dense(1, activation='sigmoid'))
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

    # The error occurs here, stating:
    # "ValueError: Error when checking input: expected dense_1_input to have 2 dimensions,
    # but got array with shape (1000, 27, 2)"
    # If you look at the comments above the declaration of 'arrayOfDatasets' you will see the only array that has
    # shape of (27, 2) is the validation set. I assume this means the error comes from the
    # 'validation_data' parameter, but I am not sure what shape it wishes to have instead.
    # The documentation on the fit() method does not say to exclude the validation_data parameter when using
    # a Sequence().
    model.fit(sequence, epochs=num_epochs, validation_data=(np.array(xValid), np.array(yValid)), verbose=1)

    # yValPred = model.predict_classes(np.array(X_val))
    yTestPred = model.predict_classes(np.array(xTest))

    # Compute the accuracy of the predicted values
    sklearn_acc = metrics.accuracy_score(yTest, yTestPred)
    print('accuracy from sklearn is:', sklearn_acc)

    # # Compute the f1 score of the predicted values
    f1 = metrics.f1_score(yTest, yTestPred)
    print('f1 is:', f1)

def undersampling(nonMasers, masers, maserCount):
    # Returns a sequence (nd-array) of 1,000 undersampled datasets to be fed tot he neural network, one new
    # set for each epoch to train on

    ####################################################################################################################
    ######################################## Perform Undersampling of NonMaser Data ####################################
    # Create a random sampling of training data from the nonMaser list
    # Creates a data range the size of the nonMaser dataset for undersampling purposes
    upperBound = len(nonMasers)
    dataRange = range(0, upperBound)

    # Number of undersampled datasets that will be created
    iterationNum = range(0, 1000)

    # The list of dataset lists
    # Will contain 1000 rows, each with 6 columns
    # The columns will be: [X_train, y_train, X_val, y_val, X_test, y_test] datasets
    result = []

    for value in iterationNum:
        # Choose k number of random nonMaser galaxies where k = number of Maser galaxies
        chosen = random.sample(dataRange, k=maserCount)

        # Build the X dataset for use in the neural network training based on the randomly selected nonMaser galaxies
        # ALTERNATE adding maser, non-maser to X data set
        X = []
        # Create the class value list to go with the data set for accuracy testing
        Class = []
        count = 0
        for value in chosen:
            X.append(nonMasers[value])
            Class.append(0)
            X.append((masers[count]))
            Class.append(1)
            count += 1

        # print(X)
        # print(Class)

        #################################### Testing the Neural network Model ##########################################
        # Implements Stratified Test Set Validation to test accuracy of KNN model

        # Creates a random selection of Train and Test data
        # Test data is 20%, Train data is 80%
        randNum = random.randint(0, 100)
        X_train, X_test, y_train, y_test = train_test_split(X, Class, test_size=0.2, random_state=randNum)

        # Creates a random selection of Train and Validation data
        # Validation is 25% of Train data, which is 20% of the total data
        # Train set is now 60% of total dataset
        X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.25, random_state=randNum)

        result.append([np.array(X_train), np.array(y_train), np.array(X_val), np.array(y_val), np.array(X_test),
                       np.array(y_test)])

    return np.array(result)
    #####################

if __name__ == '__main__':
    main()
